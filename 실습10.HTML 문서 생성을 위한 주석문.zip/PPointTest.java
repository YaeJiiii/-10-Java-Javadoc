import kr.ac.kookmin.cs.*;

/**
     * PPointTest import from kr.ac.kookmin.cs
     * So to make directory, PPoint.java file has to locate in C:\JavaLab\kr\ac\kookmin\cs
     * PPoint 객체를 생성한 후 x좌표 y좌표에 10, 20을 넣음

   */

class PPointTest {
    public static void main(String args[]) {
        PPoint aObj = new PPoint(10, 20);
        System.out.println("aObj(x, y) = " + aObj.getX() + ", "+ aObj.getY());
    }
}
