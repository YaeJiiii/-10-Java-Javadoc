package kr.ac.kookmin.cs;

public class PPoint {
    /**
     * PPoint class involves in kr.ac.kookmin.cs package
     * @param x정수형 x좌표 , y 정수형 y좌표
     * @return x좌표 필드값, y좌표 필드값
   */

    int xA;
    int yA;
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
    public int getX() {
        return xA;
    }
    public int getY() {
        return yA;
    }
}
